
## Requirements

- `npm` or `yarn`

## Installation

```bash
npm install # or yarn
npm run dev # or yarn dev
```
